const express = require('express');
const cors = require('cors');  // Import cors
const crypto = require('crypto');
const bodyParser = require('body-parser');

const app = express();

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));

// Use CORS middleware
app.use(cors());

const MERCHANT_ID = "T1043733"; // Your Merchant ID
const SALT = "5981514647TMLRTF"; // Replace with actual salt

// Token generation route
app.post('/generate-token', (req, res) => {
    const { amount, consumerId, txnId } = req.body;

    if (!amount || !consumerId || !txnId) {
        return res.status(400).json({ error: 'Missing required parameters' });
    }

    const currency = "INR";  // Define the currency
    const stringToHash = `${MERCHANT_ID}|${txnId}|${amount}|${currency}|${consumerId}|NA|NA|NA|NA|NA|NA|NA|NA|${SALT}`;

    // Generate the hash using SHA-256
    const hash = crypto.createHash('sha256').update(stringToHash).digest('hex');

    // Return the token to the client
    res.json({ token: hash });
});

